package com.manh.warehousedescription;

import com.manh.warehouse.Warehouse;

public class WarehouseDescription {
	private int warehouseId;
	private int zone;
	private int aisle;
	private int bay;
	private int level;
	private int bin;
	private Warehouse warehouse;
	
	public WarehouseDescription() {
		super();
		// TODO Auto-generated constructor stub
	}


	public WarehouseDescription(Warehouse warehouse, int zone, int aisle, int bay, int level, int bin) {
		super();
		this.warehouse = warehouse;
		this.zone = zone;
		this.aisle = aisle;
		this.bay = bay;
		this.level = level;
		this.bin = bin;
		
	}
	

	public int getWarehouseId() {
		return this.warehouseId;
	}


	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}


	public Warehouse getWarehouse() {
		return warehouse;
	}

	public void setWarehouse(Warehouse warehouse) {
		this.warehouse = warehouse;
	}

	public int getZone() {
		return zone;
	}

	public void setZone(int zone) {
		this.zone = zone;
	}





	public int getAisle() {
		return aisle;
	}


	public void setAisle(int aisle) {
		this.aisle = aisle;
	}


	public int getBay() {
		return bay;
	}


	public void setBay(int bay) {
		this.bay = bay;
	}


	public int getLevel() {
		return level;
	}


	public void setLevel(int level) {
		this.level = level;
	}


	public int getBin() {
		return bin;
	}


	public void setBin(int bin) {
		this.bin = bin;
	}


	@Override
	public String toString() {
		return "WarehouseDescriptionModule [warehouse=" + warehouse + ", zone=" + zone + ", aisle=" + aisle + ", bay="
				+ bay + ", level=" + level + ", bin=" + bin + "]";
	}

	
}
