package com.manh.items;

public class Category {
	private int categoryId;
	private String categoryName;
	private String subcategoryName;
	public Category(String categoryName, String subcategoryName) {
		super();
//		this.id = id;
		this.categoryName = categoryName;
		this.subcategoryName = subcategoryName;
	}
	
	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}

	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", categoryName=" + categoryName + ", subcategoryName="
				+ subcategoryName + "]";
	}
	
	
}
