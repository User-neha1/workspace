package com.manh.processmodules;

import java.util.ArrayList;

import com.manh.interfaces.ReportingOperations;

public class AdminOperationModule extends UserOperationModule implements ReportingOperations{

	@Override
	public ArrayList turnOver() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList stockQuantity() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList slowMovingItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList obsoleteStockAnalysis() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList expiredDrugAnalysis() {
		// TODO Auto-generated method stub
		return null;
	}

}
