package com.manh.processmodules;

import com.manh.interfaces.WarehouseManagement;
import com.manh.warehouse.Warehouse;

public class WarehouseProcessModule implements WarehouseManagement {

	@Override
	public boolean addWarehouse(Warehouse warehouseId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteWarehouse(int warehouseId) {
		// TODO Auto-generated method stub         
		return false;
	}

	@Override
	public boolean searchWarehouse(int warehouseId) {
		// TODO Auto-generated method stub
		return false;
	}

}
