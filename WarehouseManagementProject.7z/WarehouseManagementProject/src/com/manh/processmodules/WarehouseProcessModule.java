package com.manh.processmodules;



import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.manh.hibernate.HibernateUtil;
import com.manh.interfaces.WarehouseManagement;
import com.manh.warehouse.Warehouse;

public class WarehouseProcessModule implements WarehouseManagement {

	@Override
	public boolean addWarehouse(Warehouse warehouseId) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(warehouseId);
		transaction.commit();
		session.close();
		return false;
	}

	@Override
	public boolean deleteWarehouse(int warehouseId) {
		// TODO Auto-generated method stub         
		return false;
	}

	@Override
	public boolean searchWarehouse(int warehouseId) {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Query query=session.createQuery("from Warehouse W where W.warehouseId=:Id");
		query.setParameter("Id",warehouseId);
		List list2=query.list();
		System.out.println(list2.size());
		Iterator itr2=((java.util.List) list2).iterator();
		while(itr2.hasNext())
		{
			System.out.println(itr2.next());
		}
		transaction.commit();
		session.close();
		return false;
	}

}
