package com.manh.processmodules;

public class PickupZoneProcessModule {
	public static boolean moveItem(int itemCode, double quantity, int initialWarehouseId, int finalWarehouseId) {
		// TODO Auto-generated method stub
		return false;
	}
	public static boolean orderManagement(int itemCode, double quantity)
	{
		return false;
	}
	public static void manageQuantity()
	{
		
	}
}
