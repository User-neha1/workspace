package com.manh.processmodules;

import java.util.ArrayList;

import org.hibernate.SessionFactory;

import com.manh.interfaces.UserOperations;
import com.manh.items.Item;
import com.manh.warehouse.Warehouse;
import com.manh.warehousedescription.WarehouseDescription;

public class UserOperationModule implements UserOperations{
	WarehouseProcessModule warehouseprocessmodule = new WarehouseProcessModule();
	@Override
	public boolean addWarehouse(Warehouse warehouseId) {
		
		warehouseprocessmodule.addWarehouse(warehouseId);
		return false;
	}

	@Override
	public boolean deleteWarehouse(int warehouseId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean searchWarehouse(int warehouseId) {
		warehouseprocessmodule.searchWarehouse(warehouseId);
		return false;
	}

	@Override
	public void addItem(Item item) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean deleteItem(int itemCode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Item searchItem(int itemCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Item> getAllItems() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateItems(Item item) {
		// TODO Auto-generated method stub
		return false;
	}

}
