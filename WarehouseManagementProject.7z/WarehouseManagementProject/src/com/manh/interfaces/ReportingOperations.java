package com.manh.interfaces;

import java.util.ArrayList;

import com.manh.warehouse.Warehouse;

public interface ReportingOperations {
	public ArrayList turnOver();
	public ArrayList stockQuantity();
	public ArrayList slowMovingItems();
	public ArrayList obsoleteStockAnalysis();
	public ArrayList expiredDrugAnalysis();
}
