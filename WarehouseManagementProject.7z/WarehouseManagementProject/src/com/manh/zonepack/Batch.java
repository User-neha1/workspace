package com.manh.zonepack;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class Batch {
	private static HashMap<Integer,Integer> batchCodeGenerator = new HashMap<Integer,Integer>();
	private int batchCode;
	private int itemCode;
	private Calendar dateOfArrival;  
	private Calendar dateOfManufacture;
	private Calendar dateOfExpiry;
	private double quantity;
	private int warehouseId;
	
	public Batch() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Batch(int itemCode, Date dateOfManufacture, Date dateOfExpiry,
			double quantity, int warehouseId) {
		super();
		if(batchCodeGenerator.get(itemCode)!=null){
			int code= batchCodeGenerator.get(itemCode);
			code++;
			batchCodeGenerator.put(itemCode, code);
		}else{
			batchCodeGenerator.put(itemCode, 101);
		}
		this.batchCode = batchCodeGenerator.get(itemCode);
		this.itemCode = itemCode;
		this.dateOfArrival = Calendar.getInstance();
		this.dateOfManufacture = Calendar.getInstance();
		this.dateOfExpiry = Calendar.getInstance();
		this.quantity = quantity;
		this.warehouseId = warehouseId;
	}
	public int getBatchCode() {
		return batchCode;
	}
	public void setBatchCode(int batchCode) {
		this.batchCode = batchCode;
	}
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public Calendar getDateOfArrival() {
		return dateOfArrival;
	}
//	public void setDateOfArrival(Date dateOfArrival) {
//		this.dateOfArrival = dateOfArrival;
//	}
	public Calendar getDateOfManufacture() {
		return dateOfManufacture;
	}
//	public void setDateOfManufacture(Date dateOfManufacture) {
//		this.dateOfManufacture = dateOfManufacture;
//	}
	public Calendar getDateOfExpiry() {
		return dateOfExpiry;
	}
//	public void setDateOfExpiry(Date dateOfExpiry) {
//		this.dateOfExpiry = dateOfExpiry;
//	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public int getWarehouseId() {
		return warehouseId;
	}
	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}
	@Override
	public String toString() {
		return "Batch [batchCode=" + batchCode + ", itemCode=" + itemCode + ", dateOfArrival=" + dateOfArrival
				+ ", dateOfManufacture=" + dateOfManufacture + ", dateOfExpiry=" + dateOfExpiry + ", quantity="
				+ quantity + ", warehouseId=" + warehouseId + "]";
	}
	
}
