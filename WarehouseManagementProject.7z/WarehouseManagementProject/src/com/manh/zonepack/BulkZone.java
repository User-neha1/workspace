package com.manh.zonepack;

public class BulkZone {
	private int warehouseId;
	private int itemCode;
	private String locationId;
	private double quantityOnHand;
	
	private static int bin=0;
	private static int level=0;
	private static int bay=0;
	private static int aisle=0;
	private static char zone=0;
	public BulkZone(int warehouseId, int itemCode, double quantityOnHand) {
		super();
		this.warehouseId = warehouseId; 
		this.itemCode = itemCode;
		this.locationId = generateItemLocation();
		this.quantityOnHand = quantityOnHand;
	}
	public String generateItemLocation(){
		StringBuffer location = new StringBuffer();;
		if(bin<2){
			bin++;
		}else{
			bin=1;
			if(level<100)
				level++;
			else{
				level=1;
				if(bay<10)
					bay++;
				else{
					bay=1;
					if(aisle<10){
						aisle++;
					}
					else{
						aisle=1;
						zone++;
						
					}
				}
				
			}
				
		}
		location.append(zone+"-"+aisle+"-"+bay+"-L"+level+"-"+bin);
		return location.toString();
	}
	public int getWarehouseId() {
		return warehouseId;
	}
	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public double getQuantityOnHand() {
		return quantityOnHand;
	}
	public void setQuantityOnHand(double quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}
	@Override
	public String toString() {
		return "BulkZone [warehouseId=" + warehouseId + ", itemCode=" + itemCode + ", locationId=" + locationId
				+ ", quantityOnHand=" + quantityOnHand + "]";
	}
	
	
	
	
}
