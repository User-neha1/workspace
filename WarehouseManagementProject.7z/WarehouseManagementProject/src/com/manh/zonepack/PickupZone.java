package com.manh.zonepack;

public class PickupZone {

}
