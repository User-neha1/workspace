package com.manh.zonepack;

import com.manh.items.Item;
import com.manh.warehouse.Warehouse;

public class PickupZone {
	private String locationId;
	private Warehouse warehouse;
	private Item item;
	private double quantityOnHand;
	private int threshold;
	public PickupZone(Warehouse warehouse, Item item, double quantityOnHand, int threshold) {
		super();
//		this.locationId = locationId;
		this.warehouse = warehouse;
		this.item = item;
		this.quantityOnHand = quantityOnHand;
		this.threshold = threshold;
	}
	public PickupZone() {
		super();
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public Warehouse getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(Warehouse warehouse) {
		this.warehouse = warehouse;
	}
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	public double getQuantityOnHand() {
		return quantityOnHand;
	}
	public void setQuantityOnHand(double quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}
	public int getThreshold() {
		return threshold;
	}
	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}
	@Override
	public String toString() {
		return "PickupZone [locationId=" + locationId + ", warehouse=" + warehouse + ", item=" + item
				+ ", quantityOnHand=" + quantityOnHand + ", threshold=" + threshold + "]";
	}
	
}
