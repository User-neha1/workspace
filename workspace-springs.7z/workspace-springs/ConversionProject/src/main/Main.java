package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.CurrencyConverterImpl;
import beans.ExchangeService;

public class Main {
	public static void main(String args[])
	{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("bean.xml");
		CurrencyConverterImpl converter=(CurrencyConverterImpl) applicationContext.getBean("converter");
		/*ExchangeService service=converter.getExchangeService();*/
		
		System.out.println("value "+converter.currencyToRupees(20,"dollar"));
	}
}
