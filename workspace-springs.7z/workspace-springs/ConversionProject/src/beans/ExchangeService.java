package beans;

import java.util.Map;

public interface ExchangeService {
	 Map getCurrencyRate();
}
