package beans;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class CurrencyConverterImpl implements CurrencyConverter{
	private ExchangeService exchangeService;
	
	public CurrencyConverterImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrencyConverterImpl(ExchangeService exchangeService) {
		super();
		this.exchangeService = exchangeService;
	}

	public ExchangeService getExchangeService() {
		return exchangeService;
	}

	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}

	@Override
	public double currencyToRupees(double currency,String currencyName) {
		Map finalAmount=exchangeService.getCurrencyRate();
		
		String name=(String)finalAmount.get(currencyName);
		double value=Double.parseDouble(name);

		double amount=value*currency;
		return amount;
		
	}

	@Override
	public String toString() {
		return "CurrencyConverterImpl [exchangeService=" + exchangeService
				+ "]";
	}

}
