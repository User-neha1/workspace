package beans;

import java.util.Map;

public class ExchangeServiceImpl implements ExchangeService{
	private Map currencyRate;
	
	
	public ExchangeServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}


	public ExchangeServiceImpl(Map currencyRate) {
		super();
		this.currencyRate = currencyRate;
	}


	public void setCurrencyRate(Map currencyRate) {
		this.currencyRate = currencyRate;
	}


	@Override
	public Map getCurrencyRate() {
		
		return currencyRate;
	}


	@Override
	public String toString() {
		return "ExchangeServiceImpl [currencyRate=" + currencyRate + "]";
	}



	

}
