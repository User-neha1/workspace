package beans;

public interface CurrencyConverter {
	

	double currencyToRupees(double currency, String currencyName);
}
