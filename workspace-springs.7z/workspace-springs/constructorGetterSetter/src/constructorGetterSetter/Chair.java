package constructorGetterSetter;

public abstract class Chair implements ChairInterface {
	private String chairType;
	private String brandName;
	public Chair() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getChairType() {
		return chairType;
	}
	public void setChairType(String chairType) {
		this.chairType = chairType;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	@Override
	public String toString() {
		return "Chair [chairType=" + chairType + ", brandName=" + brandName
				+ "]";
	}
	

}
