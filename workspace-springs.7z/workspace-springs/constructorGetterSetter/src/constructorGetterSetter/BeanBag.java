package constructorGetterSetter;

public class BeanBag extends Chair{


	@Override
	public String showChair() {
		System.out.println("chair");
		return null;
	}

}
