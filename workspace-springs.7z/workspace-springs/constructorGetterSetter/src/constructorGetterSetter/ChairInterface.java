package constructorGetterSetter;

public interface ChairInterface {
	String showChair();
	
}
