package constructorGetterSetter;

public class Student {
	private int id;
	private String name;
	private Chair chair;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Student(Chair chair) {
		super();
		this.chair = chair;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Chair getChair() {
		return chair;
	}
	public void setChair(Chair chair) {
		this.chair = chair;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", chair=" + chair
				+ "]";
	}
}
