package constructorGetterSetter;

public class Sofa extends Chair{

	public Sofa() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String showChair() {
		System.out.println("sofa");
		return null;
	}

}
