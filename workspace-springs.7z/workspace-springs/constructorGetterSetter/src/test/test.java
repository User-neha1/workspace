package test;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import constructorGetterSetter.Chair;
import constructorGetterSetter.Student;

public class test {
	public static void main(String args[])
	{
	ApplicationContext applicationContext=new ClassPathXmlApplicationContext("studentInfo.xml");
	
	Student students=(Student)applicationContext.getBean("student");
	Chair chair=students.getChair();
	students.setId(1);
	students.setName("a");
	chair.setBrandName("b");
	chair.setChairType("abc");
	System.out.println(students);
	chair.showChair();
	
	Student students1=(Student)applicationContext.getBean("student");
	Chair chair1=students1.getChair();
	students1.setId(1);
	students1.setName("a");
	chair1.setBrandName("b");
	chair1.setChairType("abc");
	System.out.println(students1);
	chair1.showChair();
	}
}
