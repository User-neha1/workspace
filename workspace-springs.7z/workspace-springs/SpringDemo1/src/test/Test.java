package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Account;
import beans.Address;
import beans.Customer;

public class Test {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("bean.xml");
		
		Customer customer=(Customer)applicationContext.getBean("customer1");
		customer.setCustomerName("rita");
		customer.setGender("female");
		
		Address address=customer.getAddress();
		address.setArea("whitefield");
		address.setCity("bangalore");
		address.setState("karnataka");
		
		Account account=customer.getAccount();
		account.setAccountNumber(1);
		account.setAccountType("general");
		System.out.println(customer);

	}

}
