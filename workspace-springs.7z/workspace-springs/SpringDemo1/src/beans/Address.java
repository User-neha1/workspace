package beans;

public class Address {
	private String area;
	private String state;
	private String city;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [area=" + area + ", state=" + state + ", city=" + city
				+ "]";
	}
	
}
