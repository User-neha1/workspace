package beans;

public class Account {
	private String accountType;
	private int accountNumber;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "Account [accountType=" + accountType + ", accountNumber="
				+ accountNumber + "]";
	}
	
	
}
