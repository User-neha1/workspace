package beans;

public class Customer {
	private String customerName;
	private String gender;
	private Address address;
	private Account account;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Customer(Account account) {
		super();
		this.account = account;
	}

	public Customer(Address address) {
		super();
		this.address = address;
	}

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", gender=" + gender
				+ ", address=" + address + ", account=" + account + "]";
	}
	
}
