package beans;

public interface CurrencyConverter {
	public double dollarToRupees(double dollar);
}
