package beans;

public class CurrencyConverterImplementation implements CurrencyConverter{
	private double currencyRate;
	
	public CurrencyConverterImplementation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrencyConverterImplementation(double currencyRate) {
		super();
		this.currencyRate = currencyRate;
	}

	public double getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(double currencyRate) {
		this.currencyRate = currencyRate;
	}

	@Override
	public String toString() {
		return "CurrencyConverterImplementation [currencyRate=" + currencyRate
				+ "]";
	}

	@Override
	public double dollarToRupees(double dollar) {
		double finalRate=dollar*currencyRate;
		return finalRate;
	}

}
