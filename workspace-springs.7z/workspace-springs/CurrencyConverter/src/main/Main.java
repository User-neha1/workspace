package main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.CurrencyConverterImplementation;

public class Main {
	public static void main(String args[])
	{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("bean.xml");
		CurrencyConverterImplementation converter=(CurrencyConverterImplementation) applicationContext.getBean("converter");
		System.out.println("Final value "+converter.dollarToRupees(10));
	}
}
