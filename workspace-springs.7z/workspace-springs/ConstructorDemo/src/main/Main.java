package main;

import model.Chair;
import model.Student;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("studentInfo.xml");
		
		Student student=(Student)applicationContext.getBean("student");
		student.setName("a");
		student.setStudentId(1);
		Chair chair=student.getChair();
		chair.setBrandName("a");
		chair.setChairType("b");
		System.out.println(student);
		Student student1=(Student)applicationContext.getBean("student");
		if(student==student1)
			System.out.println("same");
		else 
			System.out.println("different");
	}
}
