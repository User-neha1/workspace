package com.manh.automobile;

public interface Automobile {
	String start();
	String stop();
	String accelerate(int speed);
}
