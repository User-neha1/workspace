package com.manh.vehicle;

public class Car extends Vehicle{
	private int seater;
	private int maxSpeed;
	
	@Override
	public String toString() {
		return "Car [seater=" + seater + ", maxSpeed=" + maxSpeed
				+ ", vehicleNo=" + vehicleNo + ", vehicleModel=" + vehicleModel
				+ ", currentSpeed=" + currentSpeed + ", getVehicleNo()="
				+ getVehicleNo() + ", getVehicleModel()=" + getVehicleModel()
				+ ", getCurrentSpeed()=" + getCurrentSpeed() + ", start()="
				+ start() + ", stop()=" + stop() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + "]";
	}
	
	public Car(int vehicleNo, int vehicleModel, int currentSpeed, int seater,
			int maxSpeed) {
		super(vehicleNo, vehicleModel, currentSpeed);
		this.seater = seater;
		this.maxSpeed = maxSpeed;
	}

	public int getSeater() {
		return seater;
	}
	public void setSeater(int seater) {
		this.seater = seater;
	}
	public int getMaxSpeed() {
		return maxSpeed;
	}
	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}
	@Override
	public String accelerate(int speed) {
		if(currentSpeed+speed<maxSpeed)
		{
			currentSpeed=currentSpeed+speed;
		}
		else
		{
			return ("Cannot increase speed ");
		}
		return ("Cannot increase speed"+speed);
	}
	
}
