package com.manh.vehicle;

import com.manh.automobile.Automobile;

public abstract class Vehicle implements Automobile{
	
	protected int vehicleNo;
	protected int vehicleModel;
	protected int currentSpeed;
	public int getVehicleNo() {
		return vehicleNo;
	}
	public Vehicle(int vehicleNo, int vehicleModel, int currentSpeed) {
		super();
		this.vehicleNo = vehicleNo;
		this.vehicleModel = vehicleModel;
		this.currentSpeed = currentSpeed;
	}
	public void setVehicleNo(int vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public int getVehicleModel() {
		return vehicleModel;
	}
	public void setVehicleModel(int vehicleModel) {
		this.vehicleModel = vehicleModel;
	}
	public int getCurrentSpeed() {
		return currentSpeed;
	}
	public void setCurrentSpeed(int currentSpeed) {
		this.currentSpeed = currentSpeed;
	}
	@Override
	public String start() {
		// TODO Auto-generated method stub
		return "Vehicle has started";
	}
	@Override
	public String stop() {
		// TODO Auto-generated method stub
		return "Vehicle has stopped";
	}
	@Override
	public abstract String accelerate(int speed);
	@Override
	public String toString() {
		return "Vehicle [vehicleNo=" + vehicleNo + ", vehicleModel="
				+ vehicleModel + ", currentSpeed=" + currentSpeed + "]";
	}
}
