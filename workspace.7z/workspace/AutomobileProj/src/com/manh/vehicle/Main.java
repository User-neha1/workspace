package com.manh.vehicle;

public class Main {

	public static void main(String[] args) {
		Car car=new Car(1200,560,50,5,140);
		System.out.println(car.start());
		System.out.println(car.accelerate(50));
		System.out.println(car.stop());
	}

}
