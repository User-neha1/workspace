package com.manh.vehicle;

public class Bike {
	protected int maxSpeed;

	public Bike(int maxSpeed) {
		super();
		this.maxSpeed = maxSpeed;
	}
	
}
