
public abstract class Vehicle {
	protected int make;
	protected String model;
	protected String modeOfTransport;
	public int getMake() {
		return make;
	}
	public void setMake(int make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getModeOfTransport() {
		return modeOfTransport;
	}
	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}
	public Vehicle(int make, String model, String modeOfTransport) {
		super();
		this.make = make;
		this.model = model;
		this.modeOfTransport = modeOfTransport;
	}
	@Override
	public String toString() {
		return "Vehicle [make=" + make + ", model=" + model
				+ ", modeOfTransport=" + modeOfTransport + "]";
	}

	
}
