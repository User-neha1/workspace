
public class Main {

	public static void main(String[] args) {
		RiverBarge vehicle=new RiverBarge(100,"Airbus","water");
		
		System.out.println(vehicle.cruise());
		System.out.println(vehicle.dock());
		Seaplane seaplane=new Seaplane(123);
		System.out.println(seaplane.seatingCapacity(100));
		Helicopter helicopter=new Helicopter(145);
		System.out.println(helicopter.seatingCapacity(2));
	}

}
