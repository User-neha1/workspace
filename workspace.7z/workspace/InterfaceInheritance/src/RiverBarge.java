
public class RiverBarge extends Vehicle implements Sailer  {
	
	@Override
	public String dock() {
		
		return "River barge has docked";
	}

	@Override
	public String cruise() {
		// TODO Auto-generated method stub
		return "River barge has started cruise";
	}

	public RiverBarge(int make, String model, String modeOfTransport) {
		super(make, model, modeOfTransport);
		// TODO Auto-generated constructor stub
	} 
	
}
