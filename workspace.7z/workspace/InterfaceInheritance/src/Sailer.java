
public interface Sailer {
	String dock();
	String cruise();
}
