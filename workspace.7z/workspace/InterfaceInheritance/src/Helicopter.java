
public class Helicopter extends Airplane {

	@Override
	public String seatingCapacity(int seat) {
		return("capacity "+seat);
		
	}

	public Helicopter(int engineType) {
		super(engineType);
		// TODO Auto-generated constructor stub
	}

}
