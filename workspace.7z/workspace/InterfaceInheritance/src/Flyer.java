
public interface Flyer {
	String takeoff();
	String land();
	String fly();
}
