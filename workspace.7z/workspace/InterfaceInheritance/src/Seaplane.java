
public class Seaplane extends Airplane{

	@Override
	public String seatingCapacity(int seat) {
		return("capacity "+seat);
		
	}

	public Seaplane(int engineType) {
		super(engineType);
		// TODO Auto-generated constructor stub
	}

}
