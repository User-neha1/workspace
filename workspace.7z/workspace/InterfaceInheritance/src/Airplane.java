
public abstract class Airplane implements Flyer {
	protected int engineType;
	@Override
	public String toString() {
		return "Airplane [engineType=" + engineType + "]";
	}

	public int getEngineType() {
		return engineType;
	}

	public void setEngineType(int engineType) {
		this.engineType = engineType;
	}

	public Airplane(int engineType) {
		super();
		this.engineType = engineType;
	}

	@Override
	public String takeoff() {
		// TODO Auto-generated method stub
		return "Airplane is taking off";
	}

	@Override
	public String land() {
		// TODO Auto-generated method stub
		return "Airplane is landing";
	}

	@Override
	public String fly() {
		// TODO Auto-generated method stub
		return "Airplane is flying";
	}
	public abstract String seatingCapacity(int seat);
	
}
