package com.manh.main;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.manh.product.Product;
import com.manh.productdao.AdminProductProcessDao;
import com.manh.productdao.TransactionProcessDAO;
import com.manh.productdao.UserProductProcessDao;
import com.manh.product.Product;
import com.manh.shopmodule.ShopProcessModule;

public class AdminMenu {
	public static void adminInput() {
		Scanner scanInput = new Scanner(System.in);
		Scanner scanInputValue = new Scanner(System.in);
		String left = "|%-22s|%-23s|%-23s|%n";
		int exit = 0;

		do {
			try {
				System.out
						.println("*******************************************");

				System.out.println("1.Insert a product");
				System.out.println("2.View all products");
				System.out.println("3.View all transactions");
				System.out
						.println("4.View all transactions of the current day");
				System.out.println("5.Get today's total sales");

				System.out.println("6.Delete a product");
				System.out.println("7.Update the price of product");
				System.out.println("8.Update the quantity of product");

				System.out.println("9.Search a product");

				System.out.println("10.Return to main menu");

				System.out.println("11.Exit");
				System.out
						.println("*******************************************");

				System.out.println("Enter  your choice");
				int choice = scanInput.nextInt();
				switch (choice) {
				case 1:
					System.out.println("Enter product name");
					String prodName = scanInputValue.next();

					System.out.println("Enter product quantity");
					int quantity = scanInput.nextInt();
					System.out.println("Enter per unit price");
					double price = scanInput.nextDouble();

					Product product = new Product(prodName, quantity, price);
					AdminProductProcessDao.insertProduct(product);
					System.out.println("Product added");
					break;
				case 2:

					ArrayList<Product> books = AdminProductProcessDao
							.getAllProducts();
					if (books.isEmpty())
						System.out.println("Products not found");
					else {
						Iterator<Product> iterator = books.iterator();

						System.out.println("Products are");
						while (iterator.hasNext()) {
							System.out.println(iterator.next());
						}
					}
					break;
				case 3:
					ResultSet resultSet = TransactionProcessDAO
							.getAllTransactions();
					if (!resultSet.next()) {
						System.out.println("No transactions recorded");

					} else {
						System.out.println("      " + "TRANSACTION ID"
								+ "           " + "BILL AMOUNT" + "          "
								+ "TRANSACTION DATE");
						System.out
								.println("--------------------------------------------------------------------------");

						while (resultSet.next()) {
							System.out.format(left, resultSet.getInt(1),
									resultSet.getFloat(2),
									resultSet.getString(3));
						}
					}
					break;
				case 4:
					ResultSet resultSets = TransactionProcessDAO
							.getCurrentDayTransaction();
					if (!resultSets.next()) {
						System.out
								.println("No transactions recorded for today");
					} else {
						System.out.println("      " + "TRANSACTION ID"
								+ "           " + "BILL AMOUNT" + "          "
								+ "TRANSACTION DATE");
						System.out
								.println("---------------------------------------------------------------------------");

						while (resultSets.next()) {
							System.out.format(left, resultSets.getInt(1),
									resultSets.getFloat(2),
									resultSets.getString(3));
						}
					}
					break;

				case 5:
					ResultSet resultsSet = TransactionProcessDAO
							.getCurrentDayTransaction();
					double totalBill = 0;
					if (!resultsSet.next()) {
						System.out
								.println("No transactions recorded for today");
					} else {
						while (resultsSet.next()) {
							totalBill = totalBill + resultsSet.getFloat(2);
						}
					}
					System.out.println("Total sales for today " + totalBill);
					break;
				case 6:
					System.out.println("Enter product ID");
					int productId = scanInputValue.nextInt();
					int deleteResult = AdminProductProcessDao
							.deleteProduct(productId);
					if (deleteResult <= 0)
						System.out.println("Product not deleted");
					else
						System.out.println("Product deleted");
					break;

				case 7:
					System.out.println("Enter product ID");
					int prodId = scanInputValue.nextInt();
					System.out.println("Enter price");
					double prodPrice = scanInputValue.nextDouble();
					int updateResult = AdminProductProcessDao.updateProduct(
							prodId, prodPrice);

					if (updateResult <= 0)
						System.out.println("Product not updated");
					else
						System.out.println("Product updated");
					break;
				case 8:
					System.out.println("Enter product ID");
					int productIds = scanInputValue.nextInt();
					System.out.println("Enter quantity");
					double productQuantity = scanInputValue.nextDouble();
					int updatesResult = AdminProductProcessDao
							.updateExistingQuantity(productIds, productQuantity);

					if (updatesResult <= 0)
						System.out.println("Product not updated");
					else
						System.out.println("Product updated");
					break;

				case 9:
					System.out.println("Enter product ID");
					int productsId = scanInputValue.nextInt();
					Product products = AdminProductProcessDao
							.getProduct(productsId);
					if (products != null)
						System.out.println(products);
					else
						System.out.println("Product not found");
					break;

				case 10:
					MainMenu.main(null);

					break;
				case 11:
					exit = 1;
					System.out
							.println("\nAre you sure you want to exit the App?\n");
					System.out.println("Type Y for yes");
					System.out.println("Type N for no ");

					while (true) {
						try {
							String exitDecide = scanInput.next();
							switch (exitDecide) {
							case "n":
							case "N":
								MainMenu.main(null);
								break;
							case "y":
							case "Y":
								System.out.println("\nTHANK YOU");
								System.exit(0);
								break;
							default:
								System.out
										.println("Invalid input.Please enter y/n corresponding to service needed\n");
							}
						} catch (java.util.InputMismatchException excep) {
							System.out
									.println("Invalid input.Please enter a valid request");
						}

					}

				default:
					exit = 1;
					System.out
							.println("Invalid input.Please enter a valid number corresponding to service needed");
					break;

				}
			}

			catch (InputMismatchException err) {
				System.out
						.println("Invalid input.Please enter a valid number corresponding to service needed");

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} while (exit != 1);
	}
}
