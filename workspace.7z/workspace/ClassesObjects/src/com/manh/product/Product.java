package com.manh.product;

import java.util.Random;

public class Product {

	private int productId;
	private String prodName;
	private double prodQuantity;
	private double prodprice;

	public Product(String prodName, double prodQuantity, double prodprice) {
		super();
		this.productId = generateProductId();
		this.prodQuantity = prodQuantity;
		this.prodName = prodName;
		this.prodprice = prodprice;
	}

	public Product() {
		super();
	}

	public static int generateProductId() {
		Random number = new Random();
		int prodNo = number.nextInt();
		return Math.abs(prodNo);
	}

	public String getName() {
		return prodName;
	}

	public void setName(String prodName) {
		this.prodName = prodName;
	}

	public double getQuantity() {
		return prodQuantity;
	}

	public void setQuantity(double prodQuantity) {
		this.prodQuantity = prodQuantity;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public double getProdprice() {
		return prodprice;
	}

	public void setProdprice(double prodprice) {
		this.prodprice = prodprice;
	}

	@Override
	public String toString() {
		return "prodName=" + prodName + ", prodQuantity=" + prodQuantity
				+ ", prodprice=" + prodprice + ", productId=" + productId;
	}
}
