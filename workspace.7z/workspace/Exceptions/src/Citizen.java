
public class Citizen {
	private int minAge=18;
	private int maxAge=70;
	private int age;
	private String address;
	private String defaultAddress="india";
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	

	public void getLicense() throws InvalidAgeException
	{
		
		if(age<minAge||age>maxAge)
		{
			throw new InvalidAgeException(this);
		}
		else
			System.out.println("issued");
		
		if(address.equalsIgnoreCase(defaultAddress))
		{
			System.out.println("issued");
			

		}
		else
			throw new InvalidAgeException(this);
	}
	

}
