
public class InvalidAgeException extends Exception {
	private int age;
	public InvalidAgeException(Citizen c) {
		age=c.getAge();
		String address=c.getAddress();
		// TODO Auto-generated constructor stub
	}
	
	public String getMessage()
	{
		if(age<18)
			return("underage-cannot be issued");
		else if(age>70)
			return("age limit exceeded-limit is 70");
		else
			return "address invalid";
	}

}
