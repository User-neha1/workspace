import java.util.Scanner;


public class Main {
	public static void main(String[] args)
	{
		Citizen c=new Citizen();
		System.out.println("enter age");
		c.setAge(70);
		c.setAddress("india");
			
		try
		{
		c.getLicense();
		}
		catch(InvalidAgeException e)
		{
			System.out.println("exception is"+e);
		}
	}
}
