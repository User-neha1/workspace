
public class StringOperations {
	public static void main(String args[])
	{
		String str="good morning good";
		String val="G-3-6-L2-1";
		String date="20 01 2017";
		String str1=str.concat(" morning");
		String str2=str.replace("good", "g");
		String str3=str.replaceAll("good"," g");
		String dates[]=date.split(" ",2);
		for(String value:dates)
		{
			System.out.println(value+" ");
		}
		System.out.println(str1+" "+str3+"  "+str2+" "+str+" "+str.charAt(1)+" "+val.substring(6, 8));
	StringBuffer st=new StringBuffer("hi");
//	StringBuffer st="hi";
	System.out.println(st.charAt(0)+st.length()+st.substring(0, 2)+st.indexOf("g"));

	
	}
}
