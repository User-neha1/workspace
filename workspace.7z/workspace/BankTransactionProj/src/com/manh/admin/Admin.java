package com.manh.admin;

public class Admin {
	private int accountId;
	private double balance;
	private int dateOpened;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getDateOpened() {
		return dateOpened;
	}
	public void setDateOpened(int dateOpened) {
		this.dateOpened = dateOpened;
	}
	
}
