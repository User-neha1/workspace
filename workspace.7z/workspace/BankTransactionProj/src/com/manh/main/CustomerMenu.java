package com.manh.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.manh.bankoperations.CustomerOperationsModule;
import com.manh.exceptions.AccountNotFoundException;
import com.manh.exceptions.CustomerNotFoundException;
import com.manh.exceptions.InsuffecientFundsException;
import com.manh.exceptions.WithdrawalLimitExceededException;

public class CustomerMenu {
	public static void customerInputMenu() {
		Scanner scanner = new Scanner(System.in);
		int exit = 0;
		System.out.println("Enter type of service needed");

		do {
			try {
				System.out
						.println("**********************************************");

				System.out.println("Type 1 to update customer address ");
				System.out.println("Type 2 to get a customer balance");
				System.out.println("Type 3 to deposit amount ");
				System.out.println("Type 4 to withdraw amount");
				System.out.println("Type 5 to transfer funds ");
				System.out.println("Type 6 to return to main menu ");
				System.out.println("Type 7 to exit ");
				System.out.println("**********************************************");

				int choice = scanner.nextInt();
				switch (choice) {
				case 1:
					System.out.println("Enter customer Id");
					int custId = scanner.nextInt();
					CustomerOperationsModule admin = new CustomerOperationsModule();
					System.out.println("Enter customer address");
					String custAddress = scanner.next();
					try {
						String updateCustomer = admin.updateAddress(custId,custAddress);
						System.out.println(updateCustomer);
					} catch (CustomerNotFoundException e) {
						System.out.println(e.getMessage());
						CustomerMenu.customerInputMenu();
					}

					break;

				case 2:

					System.out.println("Enter account Id");
					int customersId = scanner.nextInt();
					CustomerOperationsModule admins = new CustomerOperationsModule();
					try {
						double customersDetail = admins.getCustomerBalance(customersId);
						System.out.println("Current balance is "+ customersDetail);
					} catch (AccountNotFoundException e) {
						System.out.println(e.getMessage());
						CustomerMenu.customerInputMenu();
					}
					break;
				case 3:
					System.out.println("Enter account Id");
					int accId = scanner.nextInt();
					CustomerOperationsModule customer = new CustomerOperationsModule();
					System.out.println("Enter amount to be deposited");
					double custAmount = scanner.nextDouble();
					try {
						String balanceDetails = customer.depositAmount(accId,custAmount);
						System.out.println(balanceDetails);
					} catch (AccountNotFoundException e) {
						System.out.println(e.getMessage());
						CustomerMenu.customerInputMenu();
					}

					break;
				case 4:
					System.out.println("Enter account Id");
					int accountsId = scanner.nextInt();
					CustomerOperationsModule customers = new CustomerOperationsModule();
					System.out.println("Enter amount to be withdrawn");
					double customerAmount = scanner.nextDouble();
					try{
					String balanceDetailing = customers.withdrawAmount(accountsId, customerAmount);
					System.out.println(balanceDetailing);
					}
					catch (AccountNotFoundException | InsuffecientFundsException | WithdrawalLimitExceededException e) {
						System.out.println(e.getMessage());
						CustomerMenu.customerInputMenu();
					}
					break;

				case 5:
					System.out.println("Enter first user account Id from whom money has to be transferred");
					int accountId1 = scanner.nextInt();
					System.out.println("Enter second user account Id to whom money has to be transferred");
					int accountId2 = scanner.nextInt();
					CustomerOperationsModule customerOne = new CustomerOperationsModule();
					System.out.println("Enter money to be transferred");
					double fundTransfer = scanner.nextDouble();
					try{
					String fundDetails = customerOne.transferFunds(accountId1,accountId2, fundTransfer);
					System.out.println(fundDetails);
					}
					catch (AccountNotFoundException | InsuffecientFundsException | WithdrawalLimitExceededException e) {
						System.out.println(e.getMessage());
						CustomerMenu.customerInputMenu();
					}
					break;

				case 6:
					MainMenu.main(null);
					exit = 1;
					break;
				case 7:
					System.out
							.println("\nAre you sure you want to exit the App?\n");
					System.out.println("Type Y for yes");
					System.out.println("Type N for no ");

					while (true) {
						try {
							String exitDecide = scanner.next();
							switch (exitDecide) {
							case "n":
							case "N":
								MainMenu.main(null);
								break;
							case "y":
							case "Y":
								System.out.println("\nTHANK YOU");
								System.exit(0);
								break;
							default:
								System.out.println("Invalid input.Please enter y/n corresponding to service needed\n");
							}
						} catch (java.util.InputMismatchException excep) {
							System.out.println("Invalid input.Please enter a valid request");
							CustomerMenu.customerInputMenu();
						}
					}

				default:
					System.out.println("Invalid input.Please enter a valid number corresponding to access needed");

				}
			} catch (InputMismatchException e) {
				System.out.println("Invalid input.Please enter a valid number corresponding to access needed");
				CustomerMenu.customerInputMenu();

			}

		} while (exit != 1);

	}
	
	
}
