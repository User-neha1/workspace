package com.manh.customer;
import java.util.Random;

import com.manh.account.*;

public class Customer {
	protected int customerId;
	protected String customerName;
	protected String customerAddress;
	Account account;
	public Customer( String customerName,
			String customerAddress, Account account) {
		super();
		this.customerId =customerIdGenerate();
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.account = account;
	}
	public int customerIdGenerate()
	{
		Random number=new Random();
		int customerNumber=number.nextInt();
		return Math.abs(customerNumber);
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return " customerId=" + customerId + ", customerName="
				+ customerName + ", customerAddress=" + customerAddress
				+ ", account=" + account +" ";
	}
	
	
}
