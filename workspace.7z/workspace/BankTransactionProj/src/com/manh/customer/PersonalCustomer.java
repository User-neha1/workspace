package com.manh.customer;

import com.manh.account.Account;

public class PersonalCustomer extends Customer{
	private int homePhoneNo;
	private int workPhoneNo;
	public PersonalCustomer(String customerName,
			String customerAddress, Account account, int homePhoneNo,
			int workPhoneNo) {
		super(customerName, customerAddress, account);
		this.homePhoneNo = homePhoneNo;
		this.workPhoneNo = workPhoneNo;
	}
	public int getHomePhoneNo() {
		return homePhoneNo;
	}
	public void setHomePhoneNo(int homePhoneNo) {
		this.homePhoneNo = homePhoneNo;
	}
	public int getWorkPhoneNo() {
		return workPhoneNo;
	}
	public void setWorkPhoneNo(int workPhoneNo) {
		this.workPhoneNo = workPhoneNo;
	}
	@Override
	public String toString() {
		return "PersonalCustomer [homePhoneNo=" + homePhoneNo
				+ ", workPhoneNo=" + workPhoneNo + ", customerId=" + customerId
				+ ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", account=" + account + "]";
	}
	
	
}
