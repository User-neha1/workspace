package com.manh.exceptions;

public class AccountNotFoundException extends Exception{

	public AccountNotFoundException() {
		super("Account Id not found.Please enter valid Id");
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "CustomerNotFoundException";
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	

}