package com.manh.exceptions;


public class InsuffecientFundsException extends Exception{

		public InsuffecientFundsException() {
			super("Insuffecient funds .Please enter value within range of available funds");
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "CustomerNotFoundException";
		}

		@Override
		public String getMessage() {
			// TODO Auto-generated method stub
			return super.getMessage();
		}
		

}

