package com.manh.bankoperations;


import com.manh.customer.Customer;
import com.manh.exceptions.AccountNotFoundException;
import com.manh.exceptions.CustomerNotFoundException;
import com.manh.exceptions.InsuffecientFundsException;
import com.manh.exceptions.WithdrawalLimitExceededException;

public class CustomerOperationsModule implements CustomerOperationsPrototype{

	@Override
	public String updateAddress(int customerId,String customerAddress) throws CustomerNotFoundException{
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getCustomerId()==customerId)
			{
				currCustomer.setCustomerAddress(customerAddress);
				return "Address updated";
			}
		}
		throw new CustomerNotFoundException();
	}


	@Override
	public double getCustomerBalance(int accountId) throws AccountNotFoundException{
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId)
			{
				//return AdminOperationsModule.customerDetails;
				
				Customer currentCustomer=AdminOperationsModule.customerDetails.get(iterator);
				double newBal=currentCustomer.getAccount().getBalance();
				return newBal;
			}
		}
		throw new AccountNotFoundException();
	}

	@Override
	public String depositAmount(int accountId,double amount) throws AccountNotFoundException{
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId)
			{
				double balance=currCustomer.getAccount().getBalance()+amount;
				currCustomer.getAccount().setBalance(balance);
				return "Amount deposited";
			}
		}
		throw new AccountNotFoundException();
	}

	@Override
	public String withdrawAmount(int accountId,double money) throws AccountNotFoundException,InsuffecientFundsException,WithdrawalLimitExceededException{
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId)
			{
				if(money>50000)
				{
					throw new WithdrawalLimitExceededException();
				}
				if(currCustomer.getAccount().getBalance()<money)
				{
					throw new InsuffecientFundsException();	
				}
				else if(currCustomer.getAccount().getBalance()>=money)
				{	
				double currbalance=currCustomer.getAccount().getBalance()-money;
				currCustomer.getAccount().setBalance(currbalance);
				return ("Amount withdrawn");
				}
				
			}
			
		}
		throw new AccountNotFoundException();
}

	@Override
	public String transferFunds(int accountId1,int accountId2,double funds) throws AccountNotFoundException,InsuffecientFundsException,WithdrawalLimitExceededException{
		int valid1=0,valid2=0;
		if(accountId1==accountId2)
			return ("Account Ids cannot be same.Please enter valid different Ids");

		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId1)
			{
				valid1=1;
				if(currCustomer.getAccount().getBalance()<funds)
				{
					throw new InsuffecientFundsException();	
				}
			}
			if(currCustomer.getAccount().getAccountId()==accountId2)
			{
				valid2=1;
			}
					
		}
		if(valid1==1&&valid2==1)
		{
			for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
			{
				Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
				if(funds>50000)
					throw new WithdrawalLimitExceededException();

				if(currCustomer.getAccount().getAccountId()==accountId1)
				{
					double fundsAvailableCust1=currCustomer.getAccount().getBalance();
					double fundsTransferredCust1=fundsAvailableCust1-funds;
					currCustomer.getAccount().setBalance(fundsTransferredCust1);
					
				}
				if(currCustomer.getAccount().getAccountId()==accountId2)
				{
					double fundsAvailableCust2=currCustomer.getAccount().getBalance();
					double fundsTransferredCust2=fundsAvailableCust2+funds;
					currCustomer.getAccount().setBalance(fundsTransferredCust2);
					return ("Funds transferred");
				}
				
			}
		}
		
		throw new AccountNotFoundException();
	}

	

}
