package com.manh.bankoperations;

import com.manh.exceptions.AccountNotFoundException;
import com.manh.exceptions.CustomerNotFoundException;
import com.manh.exceptions.InsuffecientFundsException;
import com.manh.exceptions.WithdrawalLimitExceededException;

public interface CustomerOperationsPrototype {
	String updateAddress(int customerId,String customerAddress) throws CustomerNotFoundException;
	double getCustomerBalance(int customerId) throws AccountNotFoundException;
	String depositAmount(int accountId,double amount) throws AccountNotFoundException;
	String withdrawAmount(int accountId,double money) throws AccountNotFoundException, InsuffecientFundsException, WithdrawalLimitExceededException;
	String transferFunds(int accountId1,int accountId2,double funds) throws AccountNotFoundException, InsuffecientFundsException, WithdrawalLimitExceededException;
	
	
}
