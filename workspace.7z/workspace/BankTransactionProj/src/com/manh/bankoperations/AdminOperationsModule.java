package com.manh.bankoperations;

import java.util.*;

import com.manh.customer.Customer;
import com.manh.exceptions.CustomerNotFoundException;

public class AdminOperationsModule implements AdminOperationsPrototype {
	public static ArrayList<Customer> customerDetails = new ArrayList<Customer>();

	@Override
	public String addCustomer(Customer customer) {

		customerDetails.add(customer);
		return "Customer added";
	}

	@Override
	public ArrayList<Customer> getCustomer(int customerId) throws CustomerNotFoundException{
		for (int iterator = 0; iterator < customerDetails.size(); iterator++) {
			Customer currCustomer = customerDetails.get(iterator);
			if (currCustomer.getCustomerId() == customerId) {
				return customerDetails;
			}
		}
		//if (currCustomer.getCustomerId() != customerId) 
		throw new CustomerNotFoundException();
	}

	@Override
	public ArrayList<Customer> getAllCustomers() throws CustomerNotFoundException{
		if(customerDetails==null)
			throw new CustomerNotFoundException();
		else
			return customerDetails;
	}

	@Override
	public String updateAddress(int customerId, String customerAddress){

		return null;
	}

	@Override
	public double getCustomerBalance(int accountId) {

		return -1.0;
	}

}
