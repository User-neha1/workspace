package com.manh.bankoperations;

import java.util.ArrayList;

import com.manh.customer.Customer;
import com.manh.exceptions.CustomerNotFoundException;

public interface AdminOperationsPrototype {
	
	String addCustomer(Customer customer);
	 ArrayList<Customer> getCustomer(int customerId) throws CustomerNotFoundException;
	 ArrayList<Customer> getAllCustomers() throws CustomerNotFoundException;
	String updateAddress(int customerId,String customerAddress);
	double getCustomerBalance(int accountId);
}
