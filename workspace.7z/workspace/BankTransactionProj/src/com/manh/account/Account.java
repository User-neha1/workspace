package com.manh.account;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class Account {
	private int accountId;
	private double balance;
	private String dateOpened;
	public Account(double balance) {
		super();
		this.accountId = accountIdGenerate();
		this.balance = balance;
		this.dateOpened = dateOfAccOpening();
	}
	public String dateOfAccOpening()
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();
		return(dtf.format(localDate)); 
	}
	public int accountIdGenerate()
	{
		Random number=new Random();
		int accNumber=number.nextInt();
		return Math.abs(accNumber);
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getDateOpened() {
		return dateOpened;
	}
	public void setDateOpened(String dateOpened) {
		this.dateOpened = dateOpened;
	}
	@Override
	public String toString() {
		return " " + accountId + ", balance=" + balance
				+ ", dateOpened=" + dateOpened + " ";
	}
	
}
