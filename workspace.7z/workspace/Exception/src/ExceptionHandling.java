import java.util.Scanner;
import java.text.*;
import java.io.*;

public class ExceptionHandling {
	
public static void main(String[] args)
{
	
	/*Scanner s=new Scanner(System.in);
	int a;
	int b=s.nextInt();
	int c=s.nextInt();
	try{
		a=b/c;
		int ans=Integer.parseInt("good");
	}
	catch(NumberFormatException e)
	{
		System.out.println("exception1");

	}
	catch(ArithmeticException|NumberFormatException e)
	{
		System.out.println("exception"+e);
	}*/
	
	
	File file=new File("C:\\Users\\nesuresh\\Documents\\greeting.txt");
	int count=0;
	String[] newWord=new String[100];

	Scanner scanner=new Scanner(System.in);

	System.out.println("enter word");
	String word=scanner.next();
	int line=0;
	try(BufferedReader br = new BufferedReader(new FileReader(file)))
	{
		String val=br.readLine();
		
		while(!(val.equalsIgnoreCase("end")))
		{
			line++;
			newWord=val.split(" ");
			count=0;
			for(String words:newWord)
			{
				if(word.equalsIgnoreCase(words))
				{
					count++;

				}

			}
			System.out.println("In line "+line+" No of words is "+count);

			val=br.readLine();
		}

	}
	catch(FileNotFoundException e)
	{
		e.printStackTrace();

	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	finally
	{
		
	}
	
}
}
