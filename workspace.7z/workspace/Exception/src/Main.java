
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomisedException excep=new CustomisedException();
		try
		{
			excep.leave(10);
		}
		catch(InsuffecientLeaveException err)
		{
			System.out.println("excep"+err.getMessage());
		}
	}

}
