
public class InsuffecientLeaveException extends Exception{
	public final int ID=100;

	public InsuffecientLeaveException() {
		super("insuffecient leave");
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "invalid leave";
	}
	

}
