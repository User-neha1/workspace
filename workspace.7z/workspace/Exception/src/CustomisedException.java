
public class CustomisedException {
	public void leave(int days) throws InsuffecientLeaveException
	{
		int defaultLeave=5;
		if(days<defaultLeave)
		{
			throw new InsuffecientLeaveException();
			
		}
	}
}
