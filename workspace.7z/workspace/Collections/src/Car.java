import java.util.*;
public class Car implements Comparable<Car>   {
	private int carModel;
	private String carMake;
	public Car(int carModel, String carMake) {
		super();
		this.carModel = carModel;
		this.carMake = carMake;
	}
	public int getCarModel() {
		return carModel;
	}
	public void setCarModel(int carModel) {
		this.carModel = carModel;
	}
	public String getCarMake() {
		return carMake;
	}
	public void setCarMake(String carMake) {
		this.carMake = carMake;
	}
	@Override
	public String toString() {
		return "Car [carModel=" + carModel + ", carMake=" + carMake + "]";
	}
	@Override
	public int compareTo(Car c) {
		int res=getCarModel()-c.getCarModel();
		if(res==0)
		return 0;
		else if(res>0)
			return 1;
		else
			return -1;
	}
	
	
}
