import java.util.Comparator;


public class CarModelComparator implements Comparator<Car>{

	
	@Override
	public int compare(Car o1, Car o2) {
		// TODO Auto-generated method stub
		int res=o1.getCarModel()-o1.getCarModel();
		if(res==0)
			return 0;
			else if(res>0)
				return 1;
			else
				return -1;
		
		
	}


}
