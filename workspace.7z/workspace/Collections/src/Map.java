import java.util.*;
import java.util.Set;

import java.util.Map.Entry;
public class Map {
	public static void mapList()
	{
	//	Car c=new Car();
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		hm.put(10,"AAA");
		hm.put(11,"BBB");
		hm.put(12,"CCC");
		hm.put(10,"DDD");
		hm.put(13,"DDD");
		for(Entry<Integer, String> m: hm.entrySet())
		{
			System.out.println(m.getValue()+" "+m.getKey());
		}
		Iterator entries =hm.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  System.out.println(thisEntry.getKey()+" "+thisEntry.getValue());
		 
		}
		
		
		System.out.println();
		TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
		tm.put(10, "a");
		tm.put(15, "b");
		tm.put(12, "c");
		for(Entry<Integer, String> m: tm.entrySet())
		{
			System.out.println(m.getValue()+" "+m.getKey());
		}
		
		
		System.out.println();
		LinkedHashMap<Integer,String> lhm=new LinkedHashMap<Integer,String>();
		lhm.put(10, "a");
		lhm.put(15, "b");
		lhm.put(12, "c");
		for(Entry<Integer, String> m: lhm.entrySet())
		{
			System.out.println(m.getValue()+" "+m.getKey());
		}
		System.out.println();
		System.out.println();
//sort treemap based on carmodel got in car class which implements comparable
		HashMap<Car,String> hm2=new HashMap<Car,String>();
		hm2.put(new Car(10,"Ford"),"abc");		
		//CarModelComparator com=new CarModelComparator(hm2);
		//Map<Car,String> hm1=new TreeMap<Car,String>(com);
/*
		hm1.put(new Car(10,"Ford"),"abc");
		hm1.put(new Car(15,"aord"),"bc");
		hm1.put(new Car(11,"lord"),"c");*/
		/*for(Entry<Car, String> m1: hm1.entrySet())
		{
			System.out.println(m1.getValue()+" "+m1.getKey());
		}*/
		
		
		
	}
}
