import java.util.*;
public class HashTable {
	public static void display()
	{
		 Enumeration names;
		   String key;
		 
		Hashtable<String, String> hashtable = 
	              new Hashtable<String, String>();
	 
	   // Adding Key and Value pairs to Hashtable
	   hashtable.put("1","c");
	   hashtable.put("7","a");
	   hashtable.put("2","p");
	   hashtable.put("4","r");
	   hashtable.put("6","m");
	   
	   //display in random order
	 /*
	   names = hashtable.keys();
	   while(names.hasMoreElements()) {
	      key = (String) names.nextElement();
	      System.out.println("Key: " +key+ " & Value: " +
	      hashtable.get(key));
	   }*/
	   
	   //display in sorted order
	   TreeMap tm=new TreeMap(hashtable);
	   tm.putAll(hashtable);
	   names=Collections.enumeration(tm.keySet());
	   while(names.hasMoreElements()) {
		      key = (String) names.nextElement();
		      System.out.println("Key: " +key+ " & Value: " +
		      hashtable.get(key));
	   }
	   
	   //to display in order entered-linkedhashmap
	}
}
