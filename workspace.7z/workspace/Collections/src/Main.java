
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List list=new List();
		Set set=new Set();
		Map m=new Map();
		HashTable ht=new HashTable();
		QueueList ql=new QueueList();
		PriorityQueueList pql=new PriorityQueueList();
		//list.arrayListOptions();
		//list.linkedListOptions();
		//list.vectorList();
		//list.hashsetList();
		//list.treeSetList();
		//set.linkedHashSetList();
		//m.mapList();
		//ht.display();
		//ql.disp();
		pql.dispList();
	}

}
