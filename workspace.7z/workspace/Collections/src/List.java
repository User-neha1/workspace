import java.util.*;
public class List {
	public static void arrayListOptions()
	{
	ArrayList<Car> arrayList=new ArrayList<Car>();
	ArrayList<Car> arrayList1=new ArrayList<Car>();

	Car c=new Car(10,"Hyundai");
	Car c1=new Car(11,"byundai1");
	Car c2=new Car(12,"ayundai2");

	System.out.println(arrayList.size());
	
	arrayList.add(c);
	arrayList.add(0, c1);
	
	System.out.println(arrayList.contains(c1));
	System.out.println(arrayList.get(0));
	System.out.println(arrayList.indexOf(c1));
	System.out.println(arrayList.isEmpty());
	arrayList1.add(c1);
	arrayList1.add(c2);

	//nest arraylists
	arrayList.addAll(arrayList1);
	arrayList.remove(0);
	arrayList.set(0, c1);
	System.out.println(arrayList.get(0));
	
	//check if arrayList are equal
	System.out.println(arrayList.equals(arrayList));
	System.out.println(arrayList.isEmpty());
	arrayList.add(c2);
	
	
	Iterator iterator =arrayList.iterator();
	while(iterator.hasNext())
	{
		
		System.out.println(iterator.next());
	}
	//calls comparable
	System.out.println();
	Collections.sort(arrayList);
	Iterator iterators =arrayList.iterator();
	while(iterators.hasNext())
	{
		
		System.out.println(iterators.next());
	}
	//calls comparator
	System.out.println();
	Collections.sort(arrayList, new CarModelComparator());
	Iterator iterators1 =arrayList.iterator();
	while(iterators1.hasNext())
	{
		
		System.out.println(iterators1.next());
	}
	
	System.out.println();
	Collections.sort(arrayList, new CarMakeComparator());
	Iterator iterators2 =arrayList.iterator();
	while(iterators2.hasNext())
	{
		
		System.out.println(iterators2.next());
	}
	arrayList.removeAll(arrayList1);
	arrayList.clear();
	}
	public static void linkedListOptions()
	{
		Car c=new Car(10,"Hyundai");
		Car c1=new Car(11,"Hyundai1");
		Car c2=new Car(12,"Hyundai2");
		LinkedList<String> lists=new LinkedList<String>();
		lists.addFirst(c.getCarMake());
		lists.addLast(c1.getCarMake());
		lists.add(1,c2.getCarMake());
		//System.out.println(lists.contains(c));
		System.out.println(lists.get(0));
		System.out.println(lists.getLast());
		System.out.println(lists.getFirst());
		System.out.println();
		Iterator it=lists.listIterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		System.out.println();
		Iterator i1=lists.descendingIterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
		System.out.println();
		Iterator i2=lists.listIterator(1);
		while(i2.hasNext())
		{
			System.out.println(i2.next());
		}
		System.out.println();
		System.out.println(lists.peek());
		lists.clear();
	}
	public static void vectorList()
	{
		Vector<String> v=new Vector<String>();
		v.add("a");
		v.add(1, "b");
		System.out.println(v.elementAt(1));
		
	}
	public static void stackList()
	{
		
	}
}
