import java.util.*;
public class QueueList {
	public static void disp()
	{
	Queue<String> q=new LinkedList<String>();
	q.add("d");
	q.add("b");
	q.add("e");
	System.out.println(q.remove());
	System.out.println(q.peek());
	for(String qlist:q)
	{
		System.out.println(qlist);
	}
	//returns exception if no more elements present to be deleted
	System.out.println(q.remove());
	System.out.println(q.remove());
	System.out.println(q.remove());


	//returns null if no more element present to be deleted
	
	System.out.println(q.poll());
	System.out.println(q.poll());
	System.out.println(q.poll());


	}
}
