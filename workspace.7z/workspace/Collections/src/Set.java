import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;


public class Set {
	//not sorted
	//order of entering not maintained
	public static void hashsetList()
	{
		HashSet<String> h=new HashSet<String>();
		h.add("hash");
		h.add("h");
		System.out.println(h);
		Iterator i=h.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
	//sorted
	public static void treeSetList()
	{
		TreeSet<String> h=new TreeSet<String>();
		h.add("d");
		h.add("a");
		h.add("b");
		h.add("a");
		Iterator i=h.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
	//only entering order maintained
	public static void linkedHashSetList()
	{
		LinkedHashSet<String> s=new LinkedHashSet<String>();
		s.add("d");
		s.add("a");
		s.add("c");
		Iterator i=s.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}
