package com.manh.processmodule;

import java.util.ArrayList;

import com.manh.comparator.MarksComparator;
import com.manh.comparator.MarksNameComparator;
import com.manh.comparator.NameComparator;
import com.manh.student.Student;

public class ProcessModule {
	public static ArrayList<Student> student = new ArrayList<Student>();

	public static void add(Student students) {

		student.add(students);
	}

	public static  ArrayList<Student> processMarks() {
		student.sort(new MarksComparator());
		return student;
	}

	public static  ArrayList<Student> processName() {
		student.sort(new NameComparator());
		return student;
	}
	public static  ArrayList<Student> processMarksName() {
		student.sort(new MarksNameComparator());
		return student;
	}
}
