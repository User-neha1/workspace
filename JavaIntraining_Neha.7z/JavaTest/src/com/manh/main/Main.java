package com.manh.main;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.manh.processmodule.ProcessModule;
import com.manh.student.Student;

public class Main {

	public static void main(String[] args) {
		while (true) {
			System.out.println("Type 1 for Entering student details");
			System.out
					.println("Type 2 for displaying student details ordering by marks");
			System.out
					.println("Type 3 for displaying student details ordering by name");
			System.out
			.println("Type 4 for displaying student details ordering by name and marks ");
			System.out.println("Type 5 to exit");
			Scanner sc = new Scanner(System.in);
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter name");
				String name = sc.next();
				System.out.println("Enter marks");
				double marks = sc.nextDouble();
				Student student = new Student(marks, name);
				ProcessModule.add(student);
				break;
			case 2:
				ArrayList<Student> marksStudent=ProcessModule.processMarks();
				Iterator it=marksStudent.iterator();
				while(it.hasNext())
				{
					System.out.println(it.next());
				}
				break;
			case 3:
				ArrayList<Student> nameStudent=ProcessModule.processName();
				Iterator itr=nameStudent.iterator();
				while(itr.hasNext())
				{
					System.out.println(itr.next());
				}
				break;
			case 4:
				ArrayList<Student> nameMarkStudent=ProcessModule.processMarksName();
				Iterator itre=nameMarkStudent.iterator();
				while(itre.hasNext())
				{
					System.out.println(itre.next());
				}
				break;
			case 5:
				System.exit(0);
				break;
			default:

			}

		}
	}
}
