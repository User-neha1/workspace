package com.manh.comparator;

import java.util.Comparator;

import com.manh.student.Student;

public class MarksNameComparator implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		int marksResult = (int) (o1.getMarks() - o2.getMarks());
		if (marksResult > 0)
			return -1;
		else if (marksResult < 0)
			return 1;
		else if(marksResult==0)
		{
			int result = o1.getName().compareToIgnoreCase(o2.getName());
			if (result > 0)
				return 1;
			else if (result < 0)
				return -1;
			else
				return 0;
		}
		else
			return 0;
		
	}

}
