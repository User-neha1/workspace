package com.manh.comparator;

import java.util.*;
import com.manh.student.*;

public class MarksComparator implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		int marksResult = (int) (o1.getMarks() - o2.getMarks());
		if (marksResult > 0)
			return -1;
		else if (marksResult < 0)
			return 1;
		else 
			return 0;
	}

}
