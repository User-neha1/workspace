package com.manh.comparator;

import java.util.Comparator;

import com.manh.student.Student;
import com.manh.student.*;

public class NameComparator implements Comparator<Student> {

	@Override
	public int compare(Student o1, Student o2) {
		int result = o1.getName().compareToIgnoreCase(o2.getName());
		if (result > 0)
			return 1;
		else if (result < 0)
			return -1;
		else
			return 0;
	}

}
