package evenOdd;

public class EvenOdd {
	public static boolean testNum(int num)
	{
		boolean result=false;
		if(num%2==0)
		{
			result=true;
		}
		return result;
	}
}
