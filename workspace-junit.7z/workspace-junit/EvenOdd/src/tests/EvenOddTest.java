package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import evenOdd.EvenOdd;

public class EvenOddTest {

	@Test
	public void test() {
		EvenOdd obj=new EvenOdd();
		assertEquals(true,EvenOdd.testNum(3));
	}

}
