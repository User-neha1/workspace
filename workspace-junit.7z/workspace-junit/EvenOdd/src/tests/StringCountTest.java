package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import evenOdd.TestingMethods;

public class StringCountTest {

	@Test
	public void test() {
		TestingMethods test=new TestingMethods();
		assertEquals(4,test.checkChar("aaa"));
	}

}
