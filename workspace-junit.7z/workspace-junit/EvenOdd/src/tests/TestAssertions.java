package tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestAssertions {
	@Test
	public void testAssertion()
	{
		String str1=new String("abcd");
		String str2=new String("abc");
		String str3=null;
		String str4="abc";
		
		int val1=7;
		int val2=6;
		String[] expectedArray={"one","two"};
		String[] resultArray={"one","two"};
		//assertEquals(str1,str2);
		//assertTrue(val1<val2);
		//assertFalse(val1<val2);
		//assertNotEquals(str1, str2);
		//assertArrayEquals(expectedArray, resultArray);
		//assertNotSame(str1, str2);
		//assertNull(str3);
		assertNotNull(str3);
	}
}
