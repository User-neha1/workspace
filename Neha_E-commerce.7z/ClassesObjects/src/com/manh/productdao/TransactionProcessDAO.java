package com.manh.productdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.manh.data.DbManager;
import com.manh.product.Product;

public class TransactionProcessDAO {
	private static Connection con;

	public static void insertProduct(int transactionNum, double totalBill) {

		con = DbManager.getInstance();
		String str = "insert into NE_TRANSACTION values(?,?,?)";
		PreparedStatement pst = null;
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate localDate = LocalDate.now();
			String dateOfTransaction = dtf.format(localDate);

			pst = con.prepareStatement(str);
			// resultset can alter data while iterating unlike Iterator
			pst.setInt(1, transactionNum);
			pst.setFloat(2, (float) totalBill);
			pst.setString(3, dateOfTransaction);
			int res = pst.executeUpdate();
		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static ResultSet getAllTransactions() {

		// same object is called each time
		con = DbManager.getInstance();
		try {

			// insensitive-to not make the changes get reflected
			Statement st = con.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			// resultset can alter data while iterating unlike Iterator
			ResultSet rt = st.executeQuery("select * from NE_TRANSACTION");
			if (rt == null)
				return null;
			else
				return rt;

		}

		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static ResultSet getCurrentDayTransaction() {
		Product product = new Product();
		con = DbManager.getInstance();
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate localDate = LocalDate.now();
			String date = dtf.format(localDate);
			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			ResultSet rt = st.executeQuery("select * from NE_TRANSACTION where transactiondate='"
							+ date + "'" );
			if (rt == null)
				return null;
			else
				return rt;
		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static ResultSet getCurrentDaySales() {
		Product product = new Product();
		con = DbManager.getInstance();
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate localDate = LocalDate.now();
			String date = dtf.format(localDate);
			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			ResultSet rt = st
					.executeQuery("select sum(prodprice) from NE_TRANSACTION where transactiondate='"
							+ date + "' group by transactiondate");

			if (rt == null)
				return null;
			else
				return rt;
		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
