package com.manh.productdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import com.manh.data.DbManager;
import com.manh.product.Product;

public class AdminProductProcessDao {
	private static Connection con;

	public static ArrayList<Product> getAllProducts() {
		ArrayList<Product> productList = new ArrayList<Product>();
		// same object is called each time
		con = DbManager.getInstance();
		try {
			// making resultset iterate in any direction-and not make

			// insensitive-to not make the changes get reflected
			Statement st = con.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			// resultset can alter data while iterating unlike Iterator
			ResultSet rt = st.executeQuery("select * from NE_PRODUCT");
			if (rt == null) {
				return null;
			}
			while (rt.next()) {
				Product product = new Product();

				product.setProductId(rt.getInt(1));
				product.setQuantity(rt.getFloat(2));
				product.setProdprice(rt.getFloat(3));
				product.setName(rt.getString(4));
				productList.add(product);

			}
			return productList;
		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Product getProduct(int productId) {
		Product product = new Product();
		con = DbManager.getInstance();
		try {

			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			ResultSet rt = st
					.executeQuery("select * from NE_PRODUCT where productid="
							+ productId + "");

			if (rt == null) {
				return null;
			}
			while (rt.next()) {

				product.setProductId(rt.getInt(1));
				product.setQuantity(rt.getFloat(2));
				product.setProdprice(rt.getFloat(3));
				product.setName(rt.getString(4));
				return product;
			}
		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static int updateProduct(int productId, double price) {
		con = DbManager.getInstance();
		try {

			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			int rt = st.executeUpdate("update NE_PRODUCT set prodprice='"
					+ price + "' where productid=" + productId);
			if (rt <= 0)
				return 0;
			else
				return 1;

		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static int updateQuantity(int productId, double quantity) {
		con = DbManager.getInstance();
		try {

			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			int rt = st.executeUpdate("update NE_PRODUCT set prodquantity='"
					+ quantity + "' where productid=" + productId);
			if (rt <= 0)
				return 0;
			else
				return 1;

		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static int updateExistingQuantity(int productId, double quantity) {
		con = DbManager.getInstance();
		try {
			Product products = AdminProductProcessDao.getProduct(productId);
			if (products == null) {
				return 0;
			}
			double currentQuantity = products.getQuantity();

			double newQuantity = currentQuantity + quantity;

			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			int rt = st.executeUpdate("update NE_PRODUCT set prodquantity='"
					+ newQuantity + "' where productid=" + productId);
			if (rt <= 0)
				return 0;
			else
				return 1;

		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static int deleteProduct(int productId) {
		int rt = 0;
		con = DbManager.getInstance();
		try {

			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			rt = st.executeUpdate("delete from NE_PRODUCT where productid="
					+ productId);
			if (rt <= 0)
				return 0;
			else
				return 1;

		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static void insertProduct(Product product) {

		con = DbManager.getInstance();
		String str = "insert into NE_PRODUCT values(?,?,?,?)";
		PreparedStatement ps = null;
		try {

			ps = con.prepareStatement(str);
			// resultset can alter data while iterating unlike Iterator
			ps.setInt(1, product.getProductId());
			ps.setFloat(2, (float) product.getQuantity());
			ps.setFloat(3, (float) product.getProdprice());
			ps.setString(4, product.getName());

			int res = ps.executeUpdate();
		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
