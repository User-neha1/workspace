package com.manh.productdao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.manh.data.DbManager;
import com.manh.product.Product;

public class UserProductProcessDao {
	private static Connection con;

	public static ArrayList<Product> getAllProducts() {
		ArrayList<Product> productList = new ArrayList<Product>();
		// same object is called each time
		con = DbManager.getInstance();
		try {
			// making resultset iterate in any direction-and not make

			// insensitive-to not make the changes get reflected
			Statement st = con.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			// resultset can alter data while iterating unlike Iterator
			ResultSet rt = st.executeQuery("select * from NE_PRODUCT");

			while (rt.next()) {
				Product product = new Product();

				product.setProductId(rt.getInt(1));
				product.setQuantity(rt.getFloat(2));
				product.setProdprice(rt.getFloat(3));
				product.setName(rt.getString(4));
				productList.add(product);
				return productList;
			}

		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Product getProduct(int productId) {
		Product product = new Product();
		con = DbManager.getInstance();
		try {

			Statement st = con.createStatement();
			// resultset can alter data while iterating unlike Iterator
			ResultSet rt = st
					.executeQuery("select * from NE_PRODUCT where productid="
							+ productId + "");

			while (rt.next()) {

				product.setProductId(rt.getInt(1));
				product.setQuantity(rt.getFloat(2));
				product.setProdprice(rt.getFloat(3));
				product.setName(rt.getString(4));
				return product;
			}
		}
		// called when the jar file is not found
		catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
