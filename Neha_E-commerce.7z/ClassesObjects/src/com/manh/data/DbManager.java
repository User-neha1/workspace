package com.manh.data;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbManager {
	// singleton pattern to create a single object and access through it

	public static Connection getInstance() {
		// hide driver info and username and password
		Properties prop = new Properties();
		String propFileName = "MyProperty.properties";
		Connection conn = null;
		if (conn == null) {
			try {
				prop.load(new FileInputStream(propFileName));
				Class.forName(prop.getProperty("Driver"));
				conn = (Connection) DriverManager.getConnection(
						prop.getProperty("url"), prop.getProperty("username"),
						prop.getProperty("password"));
				conn.setAutoCommit(true);
			} catch (ClassNotFoundException | IOException | SQLException e) {
				System.out.println(e);
			}
		}
		return conn;
	}
}
