package com.manh.shopmodule;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.manh.product.Product;
import com.manh.productdao.AdminProductProcessDao;
import com.manh.productdao.TransactionProcessDAO;

public class ShopProcessModule {

	public static HashMap<Integer, Double> hashMap = new HashMap<Integer, Double>();

	private static double billAmount = 0;
	public static int transactionsId = 0;
	public static int transactionId = 0;

	public static String addToCart(int productId, double quantity) {
		Product product = AdminProductProcessDao.getProduct(productId);
		if (product == null)
			return ("Product not found");
		double currentQuantity = product.getQuantity();
		if (currentQuantity == 0) {
			return ("Items for the given product Id are not in stock");

		}

		if (currentQuantity >= quantity) {
			if (hashMap.get(productId) == null) {
				hashMap.put(productId, quantity);
				return ("Product with Id " + productId + " added to cart");
			} else {
				hashMap.put(productId, hashMap.get(productId) + quantity);
				return ("Product with Id " + productId + " added to cart");

			}
		} else {
			return ("Required quantity is not available for the requested product.Please reenter");
		}
	}

	public static HashMap<Integer, Double> viewCartItems() {
		return hashMap;
	}

	public static int deleteFromCart(int productId) {
		Iterator it = hashMap.entrySet().iterator();
		if (hashMap.isEmpty())
			return -1;
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			if ((int) pair.getKey() == productId) {
				it.remove(); // avoids a ConcurrentModificationException
				return 1;
			}
		}
		return 0;
	}

	public static double calculateBill() {
		int ID;
		double totalSum = 0, price = 0, quantity = 0, currentQuantity = 0;

		transactionId = (int) (Math.random() * 2000 + 1);
		Iterator iterator = hashMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry pair = (Map.Entry) iterator.next();
			ID = (int) pair.getKey();
			quantity = (double) pair.getValue();
			Product products = AdminProductProcessDao.getProduct(ID);
			currentQuantity = products.getQuantity();
			price = (int) products.getProdprice();
			totalSum = totalSum + (price * quantity);
			AdminProductProcessDao.updateQuantity(ID, currentQuantity
					- quantity);

			TransactionProcessDAO.insertProduct(transactionId, totalSum);
		}
		hashMap.clear();
		return totalSum;
	}

}
