package com.manh.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.manh.product.Product;
import com.manh.productdao.AdminProductProcessDao;
import com.manh.shopmodule.ShopProcessModule;

public class UserShopMenu {
	public static void userShopInput() {
		Scanner scanInput = new Scanner(System.in);
		Scanner scanInputValue = new Scanner(System.in);
		String left = "|%-22s|%-23s|%n";

		int exit = 0;

		do {
			try {
				System.out
						.println("*******************************************");

				System.out.println("1.Add items to cart");
				System.out.println("2.View items in cart");
				System.out.println("3.Delete items in cart");
				System.out.println("4.Calculate bill for items in cart");
				System.out.println("5.Return to main menu");
				System.out.println("6.Exit");
				System.out
						.println("*******************************************");

				System.out.println("Enter your choice");
				int choice = scanInput.nextInt();
				switch (choice) {
				case 1:

					int exitChoice = 0;
					do {
						ArrayList<Product> books = AdminProductProcessDao
								.getAllProducts();
						Iterator<Product> iterator = books.iterator();
						if (iterator != null) {
							System.out.println("Products are");
							while (iterator.hasNext()) {
								System.out.println(iterator.next());
							}
						}

						System.out
								.println("Please choose an item from above list");
						System.out.println("Please enter product id");
						int productId = scanInput.nextInt();
						System.out
								.println("Please enter quantity of product required");
						int productQuantity = scanInput.nextInt();
						String result = ShopProcessModule.addToCart(productId,
								productQuantity);
						System.out.println(result);

						System.out.println("\nDo you wish to add an item\n");
						try {
							String exitDecide = scanInput.next();
							switch (exitDecide) {
							case "n":
							case "N":
								UserShopMenu.userShopInput();
								exitChoice = 1;
								break;
							case "y":
							case "Y":

								break;
							default:
								System.out
										.println("Invalid input.Please enter y/n corresponding to service needed\n");
							}
						} catch (java.util.InputMismatchException excep) {
							System.out
									.println("Invalid input.Please enter a valid request");
						}
					} while (exitChoice != 1);

					break;
				case 2:
					HashMap<Integer, Double> cartItems = ShopProcessModule
							.viewCartItems();
					Iterator it = cartItems.entrySet().iterator();
					if (!it.hasNext()) {
						System.out.println("No items available in the cart");
					} else {

						System.out
								.println("-----------------------------------------------------------------");
						while (it.hasNext()) {
							Map.Entry pair = (Map.Entry) it.next();
							int id = (int) pair.getKey();
							Product products = AdminProductProcessDao
									.getProduct(id);
							if (products != null)
								System.out.println(products);
							else
								System.out.println("Product not found");
						}
					}
					break;
				case 3:
					System.out.println("Please enter product id");
					int productId = scanInput.nextInt();
					int valueReturned = ShopProcessModule
							.deleteFromCart(productId);
					if (valueReturned == 1)
						System.out.println("Product deleted from cart");
					else if (valueReturned == 0)
						System.out.println("Product could not be deleted");
					else if (valueReturned == -1)
						System.out.println("No products in the cart");
					break;
				case 4:
					double totalBillAmount = ShopProcessModule.calculateBill();
					System.out.println("Transaction Id "
							+ ShopProcessModule.transactionId);
					System.out.println("Total Bill=" + totalBillAmount);
					MainMenu.main(null);
					exit = 1;
					break;
				case 5:
					System.out
							.println("Are you sure you want to exit?You will lose all transactions made");
					exit = 1;
					MainMenu.main(null);
					break;
				case 6:
					exit = 1;
					System.out
							.println("\nAre you sure you want to exit the App?\n");
					System.out.println("Type Y for yes");
					System.out.println("Type N for no ");

					while (true) {
						try {
							String exitDecide = scanInput.next();
							switch (exitDecide) {
							case "n":
							case "N":
								MainMenu.main(null);
								break;
							case "y":
							case "Y":
								System.out.println("\nTHANK YOU");
								System.exit(0);
								break;
							default:
								System.out
										.println("Invalid input.Please enter y/n corresponding to service needed\n");
							}
						} catch (java.util.InputMismatchException excep) {
							System.out
									.println("Invalid input.Please enter a valid request");
						}
					}

				default:
					System.out
							.println("Invalid input.Please enter a valid number corresponding to service needed");

				}
			}

			catch (InputMismatchException err) {
				System.out
						.println("Invalid input.Please enter a valid number corresponding to service needed");

			}

		} while (exit != 1);
	}
}
