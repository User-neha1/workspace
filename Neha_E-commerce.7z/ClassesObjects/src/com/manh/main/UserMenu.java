package com.manh.main;

import java.util.*;

import com.manh.product.Product;
import com.manh.productdao.AdminProductProcessDao;
import com.manh.shopmodule.ShopProcessModule;

public class UserMenu {
	public static void userInput() {
		Scanner scanInput = new Scanner(System.in);
		Scanner scanInputValue = new Scanner(System.in);
		int exit = 0;
		do {
			try {
				System.out
						.println("*******************************************");

				System.out.println("1.View all available products");
				System.out.println("2.Shop for products");
				System.out.println("3.Search product");
				System.out.println("4.Return to main menu");
				System.out.println("5.Exit");
				System.out
						.println("*******************************************");

				System.out.println("Enter your choice");
				int choice = scanInput.nextInt();
				switch (choice) {
				case 1:
					ArrayList<Product> books = AdminProductProcessDao
							.getAllProducts();
					Iterator<Product> iterator = books.iterator();
					System.out.println("Products are");
					while (iterator.hasNext()) {
						System.out.println(iterator.next());
					}

					break;
				case 2:

					UserShopMenu.userShopInput();

					break;
				case 3:
					System.out.println("Enter product ID");
					int productsId = scanInputValue.nextInt();
					Product products = AdminProductProcessDao
							.getProduct(productsId);
					if (products != null)
						System.out.println(products);
					else
						System.out.println("Product not found");
					break;
				case 4:
					exit = 1;
					MainMenu.main(null);
					break;
				case 5:
					exit = 1;
					System.out
							.println("\nAre you sure you want to exit the App?\n");
					System.out.println("Type Y for yes");
					System.out.println("Type N for no ");

					while (true) {
						try {
							String exitDecide = scanInput.next();
							switch (exitDecide) {
							case "n":
							case "N":
								MainMenu.main(null);
								break;
							case "y":
							case "Y":
								System.out.println("\nTHANK YOU");
								System.exit(0);
								break;
							default:
								System.out
										.println("Invalid input.Please enter y/n corresponding to service needed\n");
							}
						} catch (java.util.InputMismatchException excep) {
							System.out
									.println("Invalid input.Please enter a valid request");
						}
					}

				default:
					System.out
							.println("Invalid input.Please enter a valid number corresponding to service needed");

				}

			} catch (InputMismatchException err) {
				System.out
						.println("Invalid input.Please enter a valid number corresponding to service needed");

			}

		} while (exit != 1);
	}
}
