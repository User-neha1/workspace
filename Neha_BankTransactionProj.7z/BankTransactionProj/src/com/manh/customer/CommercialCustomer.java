package com.manh.customer;

import com.manh.account.Account;

public class CommercialCustomer extends Customer {
	private int contactPersonPhoneNo;
	private String contactPersonName;
	public CommercialCustomer(String customerName,
			String customerAddress, Account account, int contactPersonPhoneNo,
			String contactPersonName) {
		super(customerName, customerAddress, account);
		this.contactPersonPhoneNo = contactPersonPhoneNo;
		this.contactPersonName = contactPersonName;
	}
	public int getContactPersonPhoneNo() {
		return contactPersonPhoneNo;
	}
	public void setContactPersonPhoneNo(int contactPersonPhoneNo) {
		this.contactPersonPhoneNo = contactPersonPhoneNo;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	@Override
	public String toString() {
		return "CommercialCustomer [contactPersonPhoneNo="
				+ contactPersonPhoneNo + ", contactPersonName="
				+ contactPersonName + ", customerId=" + customerId
				+ ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", account=" + account + "]";
	}
	
	
}
