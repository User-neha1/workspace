package com.manh.main;

import java.util.ArrayList;
import java.util.InputMismatchException;

import com.manh.bankoperations.*;

import java.util.*;

import com.manh.customer.*;
import com.manh.account.*;

public class AdminMenu {
	public static void adminInputMenu()
	{
	Scanner scanner=new Scanner(System.in);
	int exit=0;
	System.out.println("Enter type of service needed");

	do{
	try
	{
		System.out.println("**********************************************");
		System.out.println("Type 1 to add customer ");
		System.out.println("Type 2 to get a customer ");
		System.out.println("Type 3 to get all customers ");
		System.out.println("Type 4 to update customer address");
		System.out.println("Type 5 to get customer balance ");
		System.out.println("Type 6 to return to main menu ");
		System.out.println("Type 7 to exit ");
		System.out.println("**********************************************");



		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1:
				System.out.println("Enter type of customer ");
				int exitChoice=0;
				do{
					

					try
					{
						System.out.println("1. Personal customer ");
						System.out.println("2. Commercial customer ");

						int customerChoice=scanner.nextInt();
						switch(customerChoice)
						{
						case 1:
							System.out.println("Enter customer name");
							String customerName=scanner.next();
							System.out.println("Enter customer address ");
							String customerAddress=scanner.next();
							int balance=0;
							
							System.out.println("Enter customer home phone number ");
							int homeNo=scanner.nextInt();
							System.out.println("Enter customer work phone number ");
							int workNo=scanner.nextInt();
							Account account=new Account(balance);
							PersonalCustomer customer=new PersonalCustomer(customerName,customerAddress,account,
									homeNo,workNo);
							AdminOperationsModule admin=new AdminOperationsModule();
							String message=admin.addCustomer(customer);
							System.out.println(message);
							exitChoice=1;
							return;
						case 2:
							System.out.println("Enter customer name");
							String custName=scanner.next();
							System.out.println("Enter customer address ");
							String custAddress=scanner.next();
							int custBalance=0;
							
							System.out.println("Enter contact person phone number ");
							int contactNo=scanner.nextInt();
							System.out.println("Enter contact person name ");
							String contactName=scanner.next();
							Account accounts=new Account(custBalance);
							CommercialCustomer customers=new CommercialCustomer(custName,custAddress,accounts,contactNo,contactName);
							AdminOperationsModule administrator=new AdminOperationsModule();
							String messages=administrator.addCustomer(customers);
							System.out.println(messages);
							exitChoice=1;
							return;
						}
					}
					catch(Exception e)
					{
						System.out.println("Enter valid choice");
					}
				}while(exitChoice!=1);
				
				
		case 2:
			
			System.out.println("Enter customer Id");
			int customerId=scanner.nextInt();
			ArrayList<Customer> customerDetail=new ArrayList<Customer>();

			AdminOperationsModule administrator=new AdminOperationsModule();
			customerDetail=administrator.getCustomer(customerId);
			
			if(customerDetail!=null)
			{
				System.out.println("Customer details are");
					System.out.println(customerDetail);
			
			}
			else
			{
				System.out.println("Customer not found");
			}
				
				break;
		case 3:
				AdminOperationsModule getAllCustomers=new AdminOperationsModule();
				ArrayList<Customer> customerDetails=new ArrayList<Customer>();
				System.out.println("Customer details are");

				customerDetails=getAllCustomers.getAllCustomers();
				if(customerDetails!=null)
				{
				for(int iterator=0;iterator<customerDetails.size();iterator++)
				{
					
						System.out.println(customerDetails.get(iterator));
					
				}
				}
				else
				{
					System.out.println("Customers not found");
				}
				break;
		case 4:
			System.out.println("Enter customer Id");
			int custId=scanner.nextInt();
			AdminOperationsModule admin=new AdminOperationsModule();
			System.out.println("Enter customer address");
			String custAddress=scanner.next();

			String updateCustomer=admin.updateAddress(custId,custAddress);
			
			if(updateCustomer!=null)
			{
						
					System.out.println(updateCustomer);
			
			}
			else
			{
				System.out.println("Customer not found");
			}
				break;
		
		case 5:

			System.out.println("Enter account Id");
			int customersId=scanner.nextInt();
			AdminOperationsModule admins=new AdminOperationsModule();
			
			double customersDetail=admins.getCustomerBalance(customersId);
			
			if(customersDetail!=-1)
			{
					System.out.println("Current Balance is "+customersDetail);
			
			}
			else
			{
				System.out.println("Customer not found");
			}
				break;
		
		case 6:
				MainMenu.main(null);
				exit=1;
				break;
		case 7:
			System.out.println("\nAre you sure you want to exit the App?\n");
			System.out.println("Type Y for yes");
			System.out.println("Type N for no ");
			
			while(true){
				try {
					String exitDecide = scanner.next();
					switch (exitDecide) {
					case "n":
					case "N":
						MainMenu.main(null);
						break;
					case "y":
					case "Y":
						System.out.println("\nTHANK YOU");
						System.exit(0);
						break;
					default:
						System.out.println("Invalid input.Please enter y/n corresponding to service needed\n");
					}
				} catch (java.util.InputMismatchException excep) {
					System.out.println("Invalid input.Please enter a valid request");
				}
			} 
			
		default:
			System.out.println("Invalid input.Please enter a valid number corresponding to access needed");

			System.exit(0);
		}
	}
	catch(InputMismatchException e)
	{
		System.out.println("Invalid input.Please enter a valid number corresponding to access needed");
	}
	
	}while(exit!=1);
	}
}
