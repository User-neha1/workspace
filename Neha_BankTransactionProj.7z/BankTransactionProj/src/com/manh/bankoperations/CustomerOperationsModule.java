package com.manh.bankoperations;

import java.util.ArrayList;

import com.manh.customer.Customer;

public class CustomerOperationsModule implements CustomerOperationsPrototype{

	@Override
	public String updateAddress(int customerId,String customerAddress) {
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getCustomerId()==customerId)
			{
				currCustomer.setCustomerAddress(customerAddress);
				return "Address updated";
			}
		}
		return null;
	}


	@Override
	public double getCustomerBalance(int accountId) {
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId)
			{
				//return AdminOperationsModule.customerDetails;
				
				Customer currentCustomer=AdminOperationsModule.customerDetails.get(iterator);
				double newBal=currentCustomer.getAccount().getBalance();
				return newBal;
			}
		}
		return -1.0;
	}

	@Override
	public String depositAmount(int accountId,double amount) {
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId)
			{
				double balance=currCustomer.getAccount().getBalance()+amount;
				currCustomer.getAccount().setBalance(balance);
				return "Amount deposited";
			}
		}
		return "Customer not found";
	}

	@Override
	public String withdrawAmount(int accountId,double money) {
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId)
			{
				if(currCustomer.getAccount().getBalance()>=money)
				{	
				double currbalance=currCustomer.getAccount().getBalance()-money;
				currCustomer.getAccount().setBalance(currbalance);
				return ("Amount withdrawn");
				}
				else
				{
					return ("Required funds not available");
				}
			}
			
		}
		return ("Customer not found");
	}

	@Override
	public String transferFunds(int accountId1,int accountId2,double funds) {
		int valid1=0,valid2=0;
		for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
		{
			Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId1)
			{
				valid1=1;
				if(currCustomer.getAccount().getBalance()<funds)
				{
					return ("Required funds not available");
				}
			}
			if(currCustomer.getAccount().getAccountId()==accountId2)
			{
				valid2=1;
			}
					
		}
		if(valid1==1&&valid2==1)
		{
			for(int iterator=0;iterator<AdminOperationsModule.customerDetails.size();iterator++)
			{
				Customer currCustomer= AdminOperationsModule.customerDetails.get(iterator);
				if(currCustomer.getAccount().getAccountId()==accountId1)
				{
					double fundsAvailable=currCustomer.getAccount().getBalance();
					double fundsTransferred=fundsAvailable-funds;
					currCustomer.getAccount().setBalance(fundsTransferred);
					
				}
				if(currCustomer.getAccount().getAccountId()==accountId2)
				{
					double fundsAvailableCust2=currCustomer.getAccount().getBalance();
					double fundsTransferredCust2=fundsAvailableCust2+funds;
					currCustomer.getAccount().setBalance(fundsTransferredCust2);
					return ("Funds transferred");
				}
				
			}
		}
		
		return ("Customer not found");
	}

	

}
