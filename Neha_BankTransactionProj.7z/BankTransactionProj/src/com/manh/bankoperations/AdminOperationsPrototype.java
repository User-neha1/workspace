package com.manh.bankoperations;

import java.util.ArrayList;

import com.manh.customer.Customer;

public interface AdminOperationsPrototype {
	
	String addCustomer(Customer customer);
	 ArrayList<Customer> getCustomer(int customerId);
	 ArrayList<Customer> getAllCustomers();
	String updateAddress(int customerId,String customerAddress);
	double getCustomerBalance(int accountId);
}
