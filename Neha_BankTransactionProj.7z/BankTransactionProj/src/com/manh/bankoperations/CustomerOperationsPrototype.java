package com.manh.bankoperations;
import java.util.ArrayList;

import com.manh.customer.*;

public interface CustomerOperationsPrototype {
	String updateAddress(int customerId,String customerAddress);
	double getCustomerBalance(int customerId);
	String depositAmount(int accountId,double amount);
	String withdrawAmount(int accountId,double money);
	String transferFunds(int accountId1,int accountId2,double funds);
	
	
}
