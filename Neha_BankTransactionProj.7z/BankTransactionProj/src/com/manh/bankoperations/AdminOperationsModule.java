package com.manh.bankoperations;

import java.util.*;

import com.manh.customer.Customer;
import com.manh.bankoperations.*;
public class AdminOperationsModule implements AdminOperationsPrototype{
	public static ArrayList<Customer> customerDetails=new ArrayList<Customer>();
	
	@Override
	public String addCustomer(Customer customer) {
		
		customerDetails.add(customer);
		return "Customer added";
	}

	@Override
	public  ArrayList<Customer> getCustomer(int customerId) {
		for(int iterator=0;iterator<customerDetails.size();iterator++)
		{
			Customer currCustomer= customerDetails.get(iterator);
			if(currCustomer.getCustomerId()==customerId)
			{
				return customerDetails;
			}
		}
		return null;
	}

	@Override
	public ArrayList<Customer> getAllCustomers() {
		return customerDetails;
	}

	@Override
	public String updateAddress(int customerId,String customerAddress) {
		for(int iterator=0;iterator<customerDetails.size();iterator++)
		{
			Customer currCustomer= customerDetails.get(iterator);
			if(currCustomer.getCustomerId()==customerId)
			{
				currCustomer.setCustomerAddress(customerAddress);
				return "Address updated";
			}
		}
		return null;
	}

	@Override
	public double getCustomerBalance(int accountId) {
		for(int iterator=0;iterator<customerDetails.size();iterator++)
		{
			Customer currCustomer= customerDetails.get(iterator);
			if(currCustomer.getAccount().getAccountId()==accountId)
			{
				Customer currentCustomer=customerDetails.get(iterator);
				double newBal=currentCustomer.getAccount().getBalance();
				return newBal;
			}
		}
		return -1.0;
	}

	

}
